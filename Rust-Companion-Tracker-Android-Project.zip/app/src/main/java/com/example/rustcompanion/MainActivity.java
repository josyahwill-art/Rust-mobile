package com.example.rustcompanion;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.Gravity;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Switch;
import android.widget.ScrollView;

public class MainActivity extends Activity {
    private int activeCount = 0;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(Color.rgb(14, 18, 24));
        getWindow().setNavigationBarColor(Color.rgb(14, 18, 24));

        ScrollView scroll = new ScrollView(this);
        scroll.setBackgroundColor(Color.rgb(14, 18, 24));
        LinearLayout page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(24, 36, 24, 28);
        scroll.addView(page);

        TextView title = new TextView(this);
        title.setText("RUST COMPANION");
        title.setTextColor(Color.WHITE);
        title.setTextSize(25);
        title.setGravity(Gravity.CENTER);
        title.setLetterSpacing(0.08f);
        page.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Manual player status checklist");
        subtitle.setTextColor(Color.rgb(160, 175, 190));
        subtitle.setTextSize(14);
        subtitle.setGravity(Gravity.CENTER);
        subtitle.setPadding(0, 8, 0, 28);
        page.addView(subtitle);

        addToggle(page, "Health checked", "Mark when you have checked your own health.");
        addToggle(page, "Food checked", "Keep track of your food status.");
        addToggle(page, "Water checked", "Keep track of your water status.");
        addToggle(page, "Inventory checked", "Mark when your inventory is organized.");
        addToggle(page, "Base secured", "A reminder to check your own base.");

        TextView note = new TextView(this);
        note.setText("This is a standalone companion checklist. It does not connect to Rust, read game data, show enemy locations, or modify gameplay.");
        note.setTextColor(Color.rgb(160, 175, 190));
        note.setTextSize(12);
        note.setPadding(4, 28, 4, 0);
        page.addView(note);

        setContentView(scroll);
    }

    private void addToggle(LinearLayout page, String label, String detail) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(18, 14, 18, 14);
        card.setBackgroundColor(Color.rgb(28, 36, 46));
        LinearLayout.LayoutParams params = new LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        params.bottomMargin = 12;
        page.addView(card, params);

        Switch toggle = new Switch(this);
        toggle.setText(label);
        toggle.setTextColor(Color.WHITE);
        toggle.setTextSize(16);
        card.addView(toggle);

        TextView hint = new TextView(this);
        hint.setText(detail);
        hint.setTextColor(Color.rgb(160, 175, 190));
        hint.setTextSize(12);
        hint.setPadding(0, 6, 0, 0);
        card.addView(hint);
    }
}
